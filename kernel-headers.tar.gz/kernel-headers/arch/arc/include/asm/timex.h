/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (C) 2004, 2007-2010, 2011-2012 Synopsys, Inc. (www.synopsys.com)
 */

#ifndef _ASM_ARC_TIMEX_H
#define _ASM_ARC_TIMEX_H

#define CLOCK_TICK_RATE	80000000 /* slated to be removed */

#include <asm-generic/timex.h>

/* XXX: get_cycles() to be implemented with RTSC insn */

#endif /* _ASM_ARC_TIMEX_H */
