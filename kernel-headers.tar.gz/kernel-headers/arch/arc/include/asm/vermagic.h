/* SPDX-License-Identifier: GPL-2.0 */

#ifndef _ASM_VERMAGIC_H
#define _ASM_VERMAGIC_H

#define MODULE_ARCH_VERMAGIC "ARC700"

#endif /* _ASM_VERMAGIC_H */
