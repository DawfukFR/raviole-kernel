/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_C6X_TLB_H
#define _ASM_C6X_TLB_H

#include <asm-generic/tlb.h>

#endif /* _ASM_C6X_TLB_H */
