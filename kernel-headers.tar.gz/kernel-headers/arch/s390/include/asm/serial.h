/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_S390_SERIAL_H
#define _ASM_S390_SERIAL_H

#define BASE_BAUD 0

#endif /* _ASM_S390_SERIAL_H */
