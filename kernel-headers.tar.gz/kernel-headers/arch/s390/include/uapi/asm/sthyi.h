/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef _UAPI_ASM_STHYI_H
#define _UAPI_ASM_STHYI_H

#define STHYI_FC_CP_IFL_CAP	0

#endif /* _UAPI_ASM_STHYI_H */
