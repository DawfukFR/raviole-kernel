extern void hp300_sched_init(irq_handler_t vector);
