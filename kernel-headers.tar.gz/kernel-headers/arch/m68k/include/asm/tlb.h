/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _M68K_TLB_H
#define _M68K_TLB_H

#include <asm-generic/tlb.h>

#endif /* _M68K_TLB_H */
